version: release-20200503-teamturkey-alpha-3

1.0 Stable and tested on AI Skirmish, Lan and Direct IP - Needs custom icons.
2.0 Extra units and tweaks
3.0 AI SUPPORT - CUSTOM ICONS - NEW UNITS AND TWEAKS

-------

WHAT IS TEAM TURKEY?

Team turkey was my solution to address that burning itch of the soviets lacking a 3rd team.

Why Turkey? Although Turkey being a soviet country isn't historically accurate neither is Red Alert (Allied Hinds anyone?), and Russia did want Turkey allied with them during the Cold War for logistical reasons, which fits the teams theme.

But most importantly, their flag is red!

I've tried to keep balance as close to the original but wa-hey, what do you expect!

-------

SO WHAT DO TURKEY GET?

Turkey is the Soviets Vanguard team, they play like you would expect soviets to play and their unique tech consists of:

Recon Bike

Advanced Communications Centre	
		------->	Fwd. Command		------->	Supply Drop 
		------->	GPS Sattellite (High Tech only)

 - The Recon Bike is good for hit and runs on the enemy base but otherwise delicate.
 - The Adv. Comm allows you to build a Fwd. Comm anywhere on the map. The Fwd. Comm provides a small amount of buildable area and allows you to call in a supply drop consisting of a couple of healing crates and a field promotion.
 - The Adv. Comm also provides GPS if you have a soviet tech centre.

-------

SO WHAT DOES EVERYONE ELSE GET?

 - The Allies pill box can now house a 2nd man. The soviets get a Guard Tower (a 1-man pill box)
 - The Allies get an A10 airstrike they can call in from off-map (requires dome/heli-pad), Soviet MIGs gets AA missiles.
 - The Allies get Orcas, Soviets get Hinds. Orcas have long range AG missiles and can spot hidden units, Hinds can carry 1 man and attack ground units.
 - The Soviets get Stavros, a Russian sniper who can shoot while cloaked and carries C4 (The allies already have Tanya).

------

ANYTHING ELSE

Map Explored is now the default setting
AI is now supported (except for Stavros)
Everything has unique icons


SUPER SECRET BONUS

I left Greece in this time, they've been my dumping team for testing new things, they're allies, get an extra A10 strike with a faster cool-down and have a one-shot mobile nuclear missile launcher (limted to 1)!!!  Yeah, I went there...


